import assert from "node:assert/strict";
import test from "node:test";
import type { Octokit } from "@octokit/rest";
import type { HostKvApi } from "@grok/agent-sdk/kv";
import { CHECK_NAME, checkDedupeKey, postGateCheck, openGateCheckWorking } from "../bot/lib/check.js";
import { checkHoldFingerprint, type GateNext, type GateState } from "../bot/lib/gate.js";
import { suiteKey } from "../bot/lib/gh.js";
import { READER_EXPECTED_SCHEMA_VERSION } from "../bot/lib/pair-record.js";
import {
  newDeliveryBudget,
  resetDeliveryBudgetFactory,
  setDeliveryBudgetFactory,
  type ReadyPair,
} from "../bot/lib/pair-observation.js";

const HEAD = "a".repeat(40);
const MOVED = "b".repeat(40);
const BASE = "c".repeat(40);
const MERGE = "e".repeat(40);
const OTHER_MERGE = "d".repeat(40);
const REF = { owner: "cryptoreporthub", repo: "subnet-dashboard", number: 1522 };

function deliveryPair(): ReadyPair {
  return { kind: "ready", prNumber: REF.number, headSha: HEAD, baseTipSha: BASE, mergeBaseSha: MERGE, draft: false, baseRef: "main" };
}

function state(next: GateNext, overrides: Partial<GateState> = {}): GateState {
  return {
    headSha: HEAD,
    mc: "PASS",
    cursor: "PASS",
    ditto: "PASS",
    replit: "PASS",
    suite: "clean",
    replitTagged: true,
    next,
    ...overrides,
  };
}

const same = (s: GateState) => ({ state: s, read: async () => s });

type Check = { name: string; sha: string; conclusion?: string; summary?: string; status?: string };

type MergeBaseReply = string | null | "empty-sha";

type WorldOptions = {
  compareThrowOnCall?: number[];
};

function seedClean(w: ReturnType<typeof world>, gate: GateState = state("mergeable")) {
  w.store.set(suiteKey(REF, HEAD, BASE), {
    state: "clean",
    at: 1,
    schemaVersion: READER_EXPECTED_SCHEMA_VERSION,
    mergeBaseSha: MERGE,
    checkHoldFingerprint: checkHoldFingerprint(gate),
  });
}

function world(
  heads: string[],
  bases: string[] = [MERGE],
  tips: string[] = [BASE],
  mergeBases: MergeBaseReply[] = [MERGE],
  options: WorldOptions = {},
) {
  const checks: Check[] = [];
  const store = new Map<string, unknown>();
  let reads = 0;
  let compareCalls = 0;
  const baseRepo = { owner: { login: REF.owner }, name: REF.repo };
  const octokit = {
    rest: {
      pulls: {
        get: async () => {
          const i = Math.min(reads, heads.length - 1);
          const baseSha = bases[Math.min(reads, bases.length - 1)];
          tips[Math.min(reads, tips.length - 1)];
          reads += 1;
          return {
            data: {
              number: REF.number,
              head: { sha: heads[i] },
              base: { sha: baseSha, ref: "main", repo: baseRepo },
              draft: false,
            },
          };
        },
        listFiles: async () => [],
        listReviews: async () => [],
      },
      issues: { listComments: async () => [] },
      repos: {
        getBranch: async () => ({
          data: { commit: { sha: tips[Math.min(Math.max(reads - 1, 0), tips.length - 1)] ?? BASE } },
        }),
        compareCommitsWithBasehead: async () => {
          const callIndex = compareCalls;
          compareCalls += 1;
          if (options.compareThrowOnCall?.includes(callIndex) === true) {
            throw new Error("compare 502");
          }
          const idx = Math.min(callIndex, mergeBases.length - 1);
          const mb = mergeBases[idx];
          return {
            data: {
              merge_base_commit:
                mb === null ? null : mb === "empty-sha" ? { sha: "" } : { sha: mb },
              files: [],
            },
          };
        },
      },
    },
  } as unknown as Octokit;
  const kv = {
    get: async (key: string) => store.get(key),
    put: async (key: string, value: unknown) => void store.set(key, value),
    delete: async (key: string) => void store.delete(key),
  } as unknown as HostKvApi;
  const baseCreateCheck = async (input: { name: string; sha: string }) => {
    const check: Check = { name: input.name, sha: input.sha };
    checks.push(check);
    return {
      update: async (patch: { status?: string; output?: { summary: string } }) => {
        if (patch.status !== undefined) {
          check.status = patch.status;
        }
      },
      conclude: async (done: { conclusion: string; output?: { summary: string } }) => {
        check.conclusion = done.conclusion;
        check.summary = done.output?.summary;
      },
    };
  };
  return { checks, store, deps: { octokit, kv, ref: REF, createCheck: baseCreateCheck } };
}

function createCheckFlakyConclude(
  base: ReturnType<typeof world>["deps"]["createCheck"],
  failBeforeSuccess: number,
) {
  let concludeAttempts = 0;
  return async (input: { name: string; sha: string }) => {
    const handle = await base(input);
    return {
      update: handle.update,
      conclude: async (done: { conclusion: string; output?: { summary: string } }) => {
        if (concludeAttempts < failBeforeSuccess) {
          concludeAttempts += 1;
          throw new Error("github 502");
        }
        return handle.conclude(done);
      },
    };
  };
}

test("A1 TC-reval-retry: first terminal conclude throws, revalidation same pair, retry posts", async () => {
  const w = world([HEAD]);
  seedClean(w, state("mergeable"));
  const createCheck = createCheckFlakyConclude(w.deps.createCheck, 1);
  const outcome = await postGateCheck({
    ...w.deps,
    createCheck,
    expectedPair: deliveryPair(),
    ...same(state("mergeable")),
  });
  assert.equal(outcome, "posted");
  assert.equal(w.checks.length, 1);
  assert.equal(w.checks[0]?.conclusion, "success");
});

test("TC-reval-drift: failed conclude, revalidation observes drift, cancels working handle", async () => {
  const w = world([HEAD, HEAD, MOVED], [MERGE, MERGE, MERGE], [BASE, BASE, BASE], [MERGE, MERGE, MERGE]);
  seedClean(w, state("mergeable"));
  const workingCheck = await createCheckFlakyConclude(w.deps.createCheck, 1)({ name: CHECK_NAME, sha: HEAD });
  const outcome = await postGateCheck({
    ...w.deps,
    expectedPair: deliveryPair(),
    workingCheck,
    ...same(state("mergeable")),
  });
  assert.equal(outcome, "stale-head");
  assert.equal(w.checks.length, 1);
  assert.equal(w.checks[0]?.conclusion, "cancelled");
  assert.match(w.checks[0]?.summary ?? "", /revalidation|drift|Superseded/i);
});

test("A2 TC-admit-drift: admission merge-base drift cancels supplied workingCheck, no second create", async () => {
  const w = world([HEAD], [MERGE], [BASE], [OTHER_MERGE]);
  seedClean(w, state("mergeable"));
  const workingCheck = await w.deps.createCheck({ name: CHECK_NAME, sha: HEAD });
  const outcome = await postGateCheck({
    ...w.deps,
    expectedPair: deliveryPair(),
    workingCheck,
    ...same(state("mergeable")),
  });
  assert.equal(outcome, "stale-head");
  assert.equal(w.checks.length, 1);
  assert.equal(w.checks[0]?.conclusion, "cancelled");
  assert.match(w.checks[0]?.summary ?? "", /admission|drift/i);
});

test("A2 TC-final-drift: final-fence drift uses existing workingCheck only", async () => {
  const w = world([HEAD, MOVED], [MERGE, MERGE], [BASE, BASE], [MERGE, MERGE]);
  seedClean(w, state("mergeable"));
  const workingCheck = await w.deps.createCheck({ name: CHECK_NAME, sha: HEAD });
  const outcome = await postGateCheck({
    ...w.deps,
    expectedPair: deliveryPair(),
    workingCheck,
    ...same(state("mergeable")),
  });
  assert.equal(outcome, "stale-head");
  assert.equal(w.checks.length, 1);
  assert.equal(w.checks[0]?.conclusion, "cancelled");
});

test("A3 TC-reval-readfail-ok: failed conclude then unreadable pair → pair-unverifiable on working handle", async () => {
  setDeliveryBudgetFactory(() => ({
    admissionReads: 2,
    finalFenceReads: 2,
    revalidationReads: 1,
    githubMutations: 2,
    createCheckCount: 1,
  }));
  try {
    const w = world([HEAD], [MERGE], [BASE], [MERGE], { compareThrowOnCall: [2] });
    seedClean(w, state("mergeable"));
    const workingCheck = await createCheckFlakyConclude(w.deps.createCheck, 1)({ name: CHECK_NAME, sha: HEAD });
    const outcome = await postGateCheck({
      ...w.deps,
      expectedPair: deliveryPair(),
      workingCheck,
      ...same(state("mergeable")),
    });
    assert.equal(outcome, "pair-unverifiable");
    assert.equal(w.checks.length, 1);
    assert.equal(w.checks[0]?.conclusion, "cancelled");
  } finally {
    resetDeliveryBudgetFactory();
  }
});

test("A3 TC-reval-readfail-bad: cancel after reval fail exhausts mutations → finalization-unresolved", async () => {
  setDeliveryBudgetFactory(() => ({
    admissionReads: 2,
    finalFenceReads: 2,
    revalidationReads: 1,
    githubMutations: 0,
    createCheckCount: 1,
  }));
  try {
    const w = world([HEAD], [MERGE], [BASE], [MERGE], { compareThrowOnCall: [2] });
    seedClean(w, state("mergeable"));
    const workingCheck = await createCheckFlakyConclude(w.deps.createCheck, 1)({ name: CHECK_NAME, sha: HEAD });
    const outcome = await postGateCheck({
      ...w.deps,
      expectedPair: deliveryPair(),
      workingCheck,
      ...same(state("mergeable")),
    });
    assert.equal(outcome, "finalization-unresolved");
  } finally {
    resetDeliveryBudgetFactory();
  }
});

test("§9 TC-double-mut-fail: two thrown terminal concludes after reval → finalization-unresolved", async () => {
  setDeliveryBudgetFactory(() => ({
    admissionReads: 2,
    finalFenceReads: 2,
    revalidationReads: 1,
    githubMutations: 2,
    createCheckCount: 1,
  }));
  try {
    const w = world([HEAD]);
    seedClean(w, state("mergeable"));
    const createCheck = createCheckFlakyConclude(w.deps.createCheck, 99);
    const outcome = await postGateCheck({
      ...w.deps,
      createCheck,
      expectedPair: deliveryPair(),
      ...same(state("mergeable")),
    });
    assert.equal(outcome, "finalization-unresolved");
  } finally {
    resetDeliveryBudgetFactory();
  }
});

test("TC-cancel-nodedupe: stale admission drift does not write check dedupe kv", async () => {
  const w = world([HEAD], [MERGE], [BASE], [OTHER_MERGE]);
  seedClean(w, state("mergeable"));
  const gate = state("mergeable");
  const hold = checkHoldFingerprint(gate);
  const dedupeKey = checkDedupeKey(REF, HEAD, BASE, MERGE, hold);
  const workingCheck = await w.deps.createCheck({ name: CHECK_NAME, sha: HEAD });
  const outcome = await postGateCheck({
    ...w.deps,
    expectedPair: deliveryPair(),
    workingCheck,
    ...same(gate),
  });
  assert.equal(outcome, "stale-head");
  assert.equal(w.store.has(dedupeKey), false);
});

test("RD-03: dedupe unchanged with open workingCheck does not leave extra concluded checks", async () => {
  const w = world([HEAD]);
  const gate = state("await_cursor_ditto", { ditto: "missing" });
  const first = await postGateCheck({ ...w.deps, expectedPair: deliveryPair(), ...same(gate) });
  assert.equal(first, "posted");
  const workingCheck = await w.deps.createCheck({ name: CHECK_NAME, sha: HEAD });
  const second = await postGateCheck({
    ...w.deps,
    expectedPair: deliveryPair(),
    workingCheck,
    ...same(gate),
  });
  assert.equal(second, "unchanged");
  assert.equal(w.checks.filter((c) => c.conclusion === "action_required").length, 1);
});

test("TC-open-update-fail: in_progress update throw still returns working handle for postGateCheck", async () => {
  const budget = newDeliveryBudget();
  const w = world([HEAD]);
  const createCheck = async (input: { name: string; sha: string }) => {
    const h = await w.deps.createCheck(input);
    return {
      update: async () => {
        throw new Error("github 403");
      },
      conclude: h.conclude,
    };
  };
  const handle = await openGateCheckWorking({
    octokit: w.deps.octokit,
    kv: w.deps.kv,
    ref: REF,
    headSha: HEAD,
    baseSha: MERGE,
    baseTipSha: BASE,
    createCheck,
    budget,
  });
  assert.notEqual(handle, undefined);
});
