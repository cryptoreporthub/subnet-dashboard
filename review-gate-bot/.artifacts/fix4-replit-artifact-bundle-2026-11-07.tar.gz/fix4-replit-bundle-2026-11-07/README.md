# Fix-4 Replit artifact bundle (2026-11-07)

**Repl `0be6701e` / subnet-dashboard-2** — freeze replay evidence only. **Not** a ship or Replit PASS verdict.

## Freeze substrate

- Upstream freeze tarball SHA-256: `8eea815eb57fdaee87b4bb2c24ff5dad4b88484914d5e088a2ab46249bc8fa87` (see `freeze-tarball.sha256` in parent packet).
- This directory is the **worker ledger + overlay** bundle; extract **inside** `review-gate-bot/` only for replay instructions below.

## Environment (required)

- **Node.js `>=22.13`** (Agent SDK / `tsx` test runner). Node 20 fails baseline replay (`tsx` missing / wrong engine).
- From `review-gate-bot/`: `npm ci && npm run check && npm test`

## Ledger (freeze `8eea815e…` extract + overlay)

| Stage | Overlay files | pass | fail | tests | Log in this bundle |
|-------|---------------|------|------|-------|-------------------|
| baseline | none | 642 | 12 | 654 | `fix4-replit-baseline-npmtest-2026-11-07.log` |
| slice (i) | `tests/suite-record.test.ts` | 653 | 2 | 654 | `fix4-replit-slice-i-npmtest-2026-11-07.log` |
| slice (ii) | + `bot/lib/check.ts`, `bot/lib/advance.ts` | 655 | 0 | 654 | `fix4-replit-slice-ii-npmtest-2026-11-07.log` |
| slice (iii)-b | + `tests/check-throw-grid.test.ts` | 666 | 0 | 666 | `fix4-replit-slice-iii-b-npmtest-2026-11-07.log` |

**653/2 ≠ 666/0** — slice (i) acceptance is separate from (iii)-b (+12 throw-grid cases after Replit pass 4 closure).

## Key artifacts

- `fix4-task3-export.patch` — apply to freeze extract (`git apply -p1`)
- `check-throw-grid.test.ts` — copy to `tests/` for (iii)-b stage
- `fix4-export-content.manifest` / `fix4-freeze-overlay.manifest`
- `fix4-replit-bundle-2026-11-07.sha256` — file integrity index (sibling in delivery tarball root)

Full doc: Project store `docs/fix4-replit-modify-artifact-bundle-2026-11-07.md`
